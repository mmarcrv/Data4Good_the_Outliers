from flask import Flask, request, jsonify

from flask_cors import CORS

app = Flask(__name__)
CORS(app)

@app.route('/generate_story', methods=['POST'])
def generate_story():
    try:
        # Retrieve data from the form submission
        victim_name = request.form.get('victim-name')
        nationality = request.form.get('nationality')
        deportation_route = request.form.get('deportation-route')
        date = request.form.get('date')

        # Always generate the same story template
        story = (
            f"{victim_name}, a courageous individual of {nationality} descent, endured the harrowing events of the Holocaust. "
            f"On {date}, they were forced along the deportation route through {deportation_route}. "
            "This journey marked a tragic chapter in history, reflecting the resilience and strength of those who faced unimaginable hardship. "
            "It is our responsibility to remember and honor their legacy, ensuring that the atrocities of the past are never forgotten."
        )

        # Return the story as a JSON response
        return jsonify({"story": story})

    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)